package repositories;

public class QuizAttempt {


    public void addQuizAttempt(int quizId, int userId) {

        System.out.println("Attempt added for quiz ID: " + quizId + " by user ID: " + userId);
    }
}
