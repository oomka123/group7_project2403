package repositories;

import models.Quiz;
import java.util.List;

public class AttemptRepository {


    public boolean quizCreation(Quiz quiz, int userId) {
        return true;
    }

    public List<Quiz> quizShowing(int userId) {

        return List.of(new Quiz("Sample Quiz", userId));
    }


    public int getLatestQuizIdForUser(int userId) {

        return 1;
    }
}
