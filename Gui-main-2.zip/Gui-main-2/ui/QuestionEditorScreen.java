package ui;

import controllers.QuestionController;
import controllers.QuizController;
import controllers.AnswerController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import models.Question;
import models.Quiz;
import models.Answer;

import java.util.List;

public class QuestionEditorScreen {
    private final VBox layout = new VBox(10);

    public QuestionEditorScreen(Navigation navigation, QuizController quizController, QuestionController questionController, AnswerController answerController) {
        Label selectQuizLabel = new Label("Select a Quiz:");
        ComboBox<Quiz> quizComboBox = new ComboBox<>();
        quizComboBox.setPromptText("Choose Quiz");

        ListView<Question> questionListView = new ListView<>();
        ComboBox<Question> questionComboBox = new ComboBox<>();
        questionComboBox.setPromptText("Select Question");

        List<Quiz> quizzes = quizController.showQuizzes(1);
        quizComboBox.getItems().addAll(quizzes);

        quizComboBox.setOnAction(e -> {
            Quiz selectedQuiz = quizComboBox.getValue();
            if (selectedQuiz != null) {
                List<Question> questions = questionController.getQuestionsByQuiz(selectedQuiz.getQuizId());
                questionListView.getItems().setAll(questions);
                questionComboBox.getItems().setAll(questions);
            }
        });

        TextField questionTextField = new TextField();
        questionTextField.setPromptText("Enter Question Text");
        Button addQuestionButton = new Button("Add Question");
        Button deleteQuestionButton = new Button("Delete Selected Question");
        Button backButton = new Button("Back");

        Label optionsLabel = new Label("Question Options:");
        ListView<String> optionsListView = new ListView<>();
        TextField optionTextField = new TextField();
        optionTextField.setPromptText("Enter Option");
        CheckBox correctCheckBox = new CheckBox("Correct Answer");
        Button addOptionButton = new Button("Add Option");
        Button removeOptionButton = new Button("Remove Selected Option");

        addOptionButton.setOnAction(e -> {
            String optionText = optionTextField.getText().trim();
            Question selectedQuestion = questionComboBox.getValue();
            boolean isCorrect = correctCheckBox.isSelected();

            if (!optionText.isEmpty() && selectedQuestion != null) {
                Answer newAnswer = new Answer(0, selectedQuestion.getQuestionId(), optionText, isCorrect);

                answerController.addAnswer(newAnswer);

                optionsListView.getItems().add(optionText + (isCorrect ? " (Correct)" : ""));

                optionTextField.clear();
                correctCheckBox.setSelected(false);
            }
        });

        removeOptionButton.setOnAction(e -> {
            String selectedOption = optionsListView.getSelectionModel().getSelectedItem();
            if (selectedOption != null) {
                optionsListView.getItems().remove(selectedOption);
            }
        });

        backButton.setOnAction(e -> navigation.showQuizMenu());

        VBox optionsLayout = new VBox(5, optionsLabel, questionComboBox, optionsListView, optionTextField, correctCheckBox, addOptionButton, removeOptionButton);
        optionsLayout.setPadding(new Insets(10));

        addQuestionButton.setOnAction(e -> {
            String questionText = questionTextField.getText().trim();
            if (!questionText.isEmpty()) {
                Question newQuestion = new Question(questionText, quizComboBox.getValue().getQuizId());
                questionController.addQuestion(newQuestion);
                questionListView.getItems().add(newQuestion);
                questionComboBox.getItems().add(newQuestion);
                questionTextField.clear();
            }
        });

        layout.getChildren().addAll(selectQuizLabel, quizComboBox, questionListView, questionTextField, addQuestionButton, deleteQuestionButton, optionsLayout, backButton);
    }

    public VBox getLayout() {
        return layout;
    }
}
