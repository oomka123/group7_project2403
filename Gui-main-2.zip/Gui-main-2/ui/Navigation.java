package ui;
import controllers.*;
import javafx.scene.Scene;
import models.*;
import javax.swing.*;
import database.*;
import repositories.*;

import javafx.stage.Stage;

public class Navigation {
    private final Stage stage;

    public Navigation(Stage stage) {
        this.stage = stage;
    }


    public void showQuizAttempt() {
        QuizAttemptScreen quizAttempt = new QuizAttemptScreen(this, new QuizController(new QuizRepository(new PostgresDB(
                "jdbc:postgresql://localhost:5432", "postgres", "0000", "abcdaa"
        ))), new QuestionController(new QuestionRepository(new PostgresDB(
                "jdbc:postgresql://localhost:5432", "postgres", "0000", "abcdaa"
        ))), new AnswerController(new AnswerRepository(new PostgresDB(
                "jdbc:postgresql://localhost:5432", "postgres", "0000", "abcdaa"
        ))));
        stage.setScene(new Scene(quizAttempt.getLayout(), 600, 400));
        stage.setTitle("Quiz Attempt");
    }


    public void showLoginScreen() {
        LoginScreen loginScreen = new LoginScreen(this, new AuthController(new UserRepository(new PostgresDB(
                "jdbc:postgresql://localhost:5432", "postgres", "0000", "abcdaa"
        ))));
        stage.setScene(new Scene(loginScreen.getLayout(), 400, 300));
        stage.setTitle("Quiz App - Login");
        stage.show();
    }

    public void showQuizMenu() {
        QuizMenuScreen quizMenu = new QuizMenuScreen(this, new QuizController(new QuizRepository(new PostgresDB(
                "jdbc:postgresql://localhost:5432", "postgres", "0000", "abcdaa"
        ))));
        stage.setScene(new Scene(quizMenu.getLayout(), 600, 400));
        stage.setTitle("Quiz Menu");
    }

    public void showQuizEditor() {
        QuizEditorScreen quizEditor = new QuizEditorScreen(this, new QuizController(new QuizRepository(new PostgresDB(
                "jdbc:postgresql://localhost:5432", "postgres", "0000", "abcdaa"
        ))));
        stage.setScene(new Scene(quizEditor.getLayout(), 600, 400));
        stage.setTitle("Quiz Editor");
    }

    public void showQuestionEditor() {
        QuestionEditorScreen questionEditor = new QuestionEditorScreen(
                this,
                new QuizController(new QuizRepository(new PostgresDB(
                        "jdbc:postgresql://localhost:5432", "postgres", "0000", "abcdaa"
                ))),
                new QuestionController(new QuestionRepository(new PostgresDB(
                        "jdbc:postgresql://localhost:5432", "postgres", "0000", "abcdaa"
                ))),
                new AnswerController(new AnswerRepository(new PostgresDB(
                        "jdbc:postgresql://localhost:5432", "postgres", "0000", "abcdaa"
                )))
        );
        stage.setScene(new Scene(questionEditor.getLayout(), 600, 400));
        stage.setTitle("Question Editor");
    }

    public void showAnswerEditor() {
        AnswerEditorScreen answerEditor = new AnswerEditorScreen(this, new QuestionController(new QuestionRepository(new PostgresDB(
                "jdbc:postgresql://localhost:5432", "postgres", "0000", "abcdaa"
        ))), new AnswerController(new AnswerRepository(new PostgresDB(
                "jdbc:postgresql://localhost:5432", "postgres", "0000", "abcdaa"
        ))));
        stage.setScene(new Scene(answerEditor.getLayout(), 600, 400));
        stage.setTitle("Answer Editor");
    }
}
