package ui;

import controllers.AnswerController;
import controllers.QuestionController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import models.Answer;
import models.Question;

import java.util.List;

public class AnswerEditorScreen {
    private final VBox layout = new VBox(10);

    public AnswerEditorScreen(Navigation navigation, QuestionController questionController, AnswerController answerController) {
        Label selectQuestionLabel = new Label("Select a Question:");
        ComboBox<Question> questionComboBox = new ComboBox<>();
        questionComboBox.setPromptText("Choose Question");

        ListView<Answer> answerListView = new ListView<>();
        TextField answerTextField = new TextField();
        answerTextField.setPromptText("Enter Answer Text");
        CheckBox isCorrectCheckBox = new CheckBox("Is Correct Answer?");
        Button addAnswerButton = new Button("Add Answer");
        Button deleteAnswerButton = new Button("Delete Selected Answer");
        Button backButton = new Button("Back");


        List<Question> questions = questionController.getQuestionsByQuiz(1);
        questionComboBox.getItems().addAll(questions);

        questionComboBox.setOnAction(e -> {
            Question selectedQuestion = questionComboBox.getSelectionModel().getSelectedItem();
            if (selectedQuestion != null) {
                List<Answer> answers = answerController.getAnswersByQuestion(selectedQuestion.getQuestionId());
                answerListView.getItems().setAll(answers);
            }
        });

        addAnswerButton.setOnAction(e -> {
            Question selectedQuestion = questionComboBox.getSelectionModel().getSelectedItem();
            String answerText = answerTextField.getText();
            boolean isCorrect = isCorrectCheckBox.isSelected();
            if (selectedQuestion != null && !answerText.isEmpty()) {
                Answer answer = new Answer(0, answerText, isCorrect, selectedQuestion.getQuestionId());
                boolean success = answerController.addAnswer(answer);
                Alert alert = new Alert(Alert.AlertType.INFORMATION, success ? "Answer added successfully!" : "Failed to add answer.");
                alert.show();
                List<Answer> answers = answerController.getAnswersByQuestion(selectedQuestion.getQuestionId());
                answerListView.getItems().setAll(answers);
            }
        });

        deleteAnswerButton.setOnAction(e -> {
            Answer selectedAnswer = answerListView.getSelectionModel().getSelectedItem();
            if (selectedAnswer != null) {
                boolean success = answerController.deleteAnswer(selectedAnswer.getAnswerId());
                Alert alert = new Alert(Alert.AlertType.INFORMATION, success ? "Answer deleted successfully!" : "Failed to delete answer.");
                alert.show();
                Question selectedQuestion = questionComboBox.getSelectionModel().getSelectedItem();
                List<Answer> answers = answerController.getAnswersByQuestion(selectedQuestion.getQuestionId());
                answerListView.getItems().setAll(answers);
            }
        });

        backButton.setOnAction(e -> navigation.showQuestionEditor());

        layout.getChildren().addAll(selectQuestionLabel, questionComboBox, answerListView, answerTextField, isCorrectCheckBox, addAnswerButton, deleteAnswerButton, backButton);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));
    }

    public VBox getLayout() {
        return layout;
    }
}
